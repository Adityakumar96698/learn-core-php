<?php
//$arr=array('Vishal','Amit','Sumit');
//print_r($arr);
//$arr=array('name'=>'Vishal','city'=>'Delhi');
//print_r($arr);
//$arr=array('Delhi','Noida','Meerut','Pune');
?>
<!--<select>
	<option>Select City</option>
	<?php
	foreach($arr as $arrList){
		echo '<option>'.$arrList.'</option>';
	}
	?>
</select>-->
<?php
$arr=array(
	array("S.No",'Name','City'),
	array("1",'Vishal','Delhi'),
	array("2",'Sumit','Noida'),
);
?>
<table border="1" cellspacing="5" cellpadding="5">
	<?php
	foreach($arr as $arrList){
		echo '<tr>';
		foreach($arrList as $arrDetail){
			echo '<td>'.$arrDetail.'</td>';
		}
		echo '</tr>';
	}
	?>
</table>