<?php
//MySql
//$con=mysql_connect("localhost","root","");
//mysql_select_db("youtube",$con);
//$sql="insert into test(name) values('Vishal')";
//$sql="select * from test";
//$res=mysql_query($sql);
//while($row=mysql_fetch_assoc($res)){
	//echo '<pre>';
	//print_r($row);
//}

//MySqli
//$con=mysqli_connect("localhost","root","","youtube");
//$sql="insert into test(name) values('Vishal')";
//$sql="select * from test";
//$res=mysqli_query($con,$sql);
//while($row=mysqli_fetch_assoc($res)){
	//echo '<pre>';
	//print_r($row);
//}

//PDO
$con=new PDO("mysql:host=localhost;dbname=youtube","root","");
//$sql="insert into test(name) values('Vishal55')";
$sql="select * from test";
$stmt=$con->prepare($sql);
$stmt->execute();
$row=$stmt->fetchAll(PDO::FETCH_ASSOC);
echo '<pre>';
print_r($row);

?>