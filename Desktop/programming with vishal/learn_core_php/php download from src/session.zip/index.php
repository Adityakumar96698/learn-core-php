<?php
session_start();
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	if($name=='Vishal'){
		$_SESSION['name']='Vishal';
		header('location:index1.php');
		die();
	}
}
?>
<form method="post">
	<input type="textbox" name="name"/>
	<input type="submit" name="submit" value="Click"/>
</form>

